module.exports ={
    callback: ({ message, args }) =>{
        console.log('bruh')
    }
}